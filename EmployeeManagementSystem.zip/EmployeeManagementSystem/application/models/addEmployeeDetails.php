<?php

class addEmployeeDetails extends CI_Model
{
	public function get_ee_api()
	{
		$response = Requests::get("https://api.elasticemail.com/v2/campaign/list?apikey=*", array());
		$resArr = array();
		$resArr = json_decode($response);
		echo "<pre>";
		print_r($resArr);
		echo "</pre>";
	}
}
