<?php include('inc/header.php') ?>
<div class="card-body contacts_body">
	<ui class="contacts">
		<h5>Employee Status</h5>
		<li>
			<div class="row">
				<a id="w3loginbtn" class="w3-bar-item w3-btn bar-item-hover w3-right"
				   style="text-align:center; padding-right:20px; margin-right: 85px; margin-left: 20px; display: inline; width: 110px; background-color: rgb(54,53,53); color: white; border-radius: 25px;"
				   href="listMaleEmployees">Male</a>
				<a id="w3loginbtn" class="w3-bar-item w3-btn bar-item-hover w3-right"
				   style="text-align:center;display: inline; width: 110px; background-color: rgb(54,53,53); color: white; border-radius: 25px;"
				   href="listFemaleEmployees">Female</a>

			</div>
		</li>
	</ui>
</div>
<?php include('inc/footer.php') ?>
