<?php include('inc/header.php') ?>
<div class="container-fluid h-100">
	<div class="row justify-content-center h-100">
		<div class="col-md-4 col-xl-3 chat">
			<div class="card mb-sm-3 mb-md-0 contacts_card">
				<div class="card-header">
					<div class="row" style="background-color: white">
						<?php echo anchor("employee/status", "Status", ['class' => 'btn btn-custom active']); ?>
						<?php echo anchor("employee/details", "Details", ['class' => 'btn btn-custom']); ?>
					</div>
				</div>
				<div class="card-body contacts_body">
					<ui class="contacts">
						<h5>Employee Status</h5>
						<li>
							<div class="row">
								<a id="w3loginbtn" class="w3-bar-item w3-btn bar-item-hover w3-right"
								   style="text-align:center; padding-right:20px; margin-right: 85px; margin-left: 20px; display: inline; width: 110px; background-color: rgb(54,53,53); color: white; border-radius: 25px;"
								   href="listMaleEmployees">Male</a>
								<a id="w3loginbtn" class="w3-bar-item w3-btn bar-item-hover w3-right"
								   style="text-align:center;display: inline; width: 110px; background-color: rgb(54,53,53); color: white; border-radius: 25px;"
								   href="listFemaleEmployees" target="_self">Female</a>

							</div>
						</li>
						<li>
							<div class="d-flex bd-highlight">
								<div class="img_cont">
									<img src="<?php echo ($data[0]['avatar']) ?>"
										 class="rounded-circle user_img">
								</div>
							</div>
						</li>
						<li>
							<div class="d-flex bd-highlight">
								<div class="img_cont">
									<img src="<?php echo ($data[4]['avatar']) ?>"
										 class="rounded-circle user_img">
								</div>
							</div>
						</li>
						<li>
							<div class="d-flex bd-highlight">
								<div class="img_cont">
									<img src="<?php echo ($data[5]['avatar']) ?>"
										 class="rounded-circle user_img">
								</div>
							</div>
						</li>
					</ui>
				</div>
				<div class="card-footer"></div>
			</div>
		</div>
	</div>
</div>
<?php include('inc/footer.php') ?>
