<?php include('inc/header.php') ?>
<div class="container-fluid h-100">
	<div class="row justify-content-center h-100">
		<div class="col-md-4 col-xl-3 chat">
			<div class="card mb-sm-3 mb-md-0 contacts_card">
				<div class="card-header">
					<div class="row" style="background-color: white">
						<?php echo anchor("employee/status", "Status", ['class' => 'btn btn-custom']); ?>
						<?php echo anchor("employee/details", "Details", ['class' => 'btn btn-custom active']); ?>
					</div>
				</div>
				<?php include("status.php") ?>
				<div class="card-footer"></div>
			</div>
		</div>
	</div>
</div>
<?php include('inc/footer.php') ?>
